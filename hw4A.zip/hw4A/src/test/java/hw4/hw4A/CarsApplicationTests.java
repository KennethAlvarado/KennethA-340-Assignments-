package hw4.hw4A;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarsApplicationTests {

	@Test
	void contextLoads() {
	}

}
